- 279 -
국제회계기준과의 관계
한국채택국제회계기준의 ‘재무보고를 위한 개념체계’와 국제회계기준의 
‘재무보고를 위한 개념체계(Conceptual Framework for Financial Reporting)’
‘재무보고를 위한 개념체계’는 국제회계기준위원회가 제정한 ‘재무보고를 위
한 개념체계(Conceptual Framework for Financial Reporting)’에 대응하는 기
준이다.
국제회계기준의 ‘재무보고를 위한 개념체계(Conceptual
Framework
for
Financial Reporting)’ 준수
‘재무보고를 위한 개념체계’는 국제회계기준의 ‘재무보고를 위한 개념체계
(Conceptual Framework for Financial Reporting)의 내용에 근거하여 전면개
정하였기 때문에 ‘재무보고를 위한 개념체계’를 따르면 국제회계기준의 ‘재무
보고를 위한 개념체계(Conceptual Framework for Financial Reporting)’도 따
르는 것이 된다.
