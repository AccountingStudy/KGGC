- 3 -
COPYRIGHT NOTICE
International Financial Reporting Standards (IFRSs) together with their accompanying documents
are issued by the International Accounting Standards Board (IASB):
7 Westferry Circus, Canary Wharf, London E14 4HD, United Kingdom.
Tel: +44 (0)20 7246 6410 Fax: +44 (0)20 7246 6411
Email: info@ifrs.org Web: www.ifrs.org
Copyright © 2023 IFRS Foundation
The IASB, the IFRS Foundation, the authors and the publishers do not accept responsibility for
loss caused to any person who acts or refrains from acting in reliance on the material in this
publication, whether such loss is caused by negligence or otherwise.
IFRSs (which include International Accounting Standards and Interpretations) are copyright of the
International Financial Reporting Standards (IFRS) Foundation.
The authoritative text of IFRSs is
that issued by the IASB in the English language.
Copies may be obtained from the IFRS
Foundation Publications Department.
Please address publication and copyright matters to:
IFRS Foundation Publications Department
7 Westferry Circus, Canary Wharf, London E14 4HD, United Kingdom.
Tel: +44 (0)20 7332 2730 Fax: +44 (0)20 7332 2749
Email: publications@ifrs.org Web: www.ifrs.org
All rights reserved.
No part of this publication may be translated, reprinted or reproduced or
utilised in any form either in whole or in part or by any electronic, mechanical or other means,
now known or hereafter invented, including photocopying and recording, or in any information
storage and retrieval system, without prior permission in writing from the IFRS Foundation.
The Korean translation of the International Financial Reporting Standards and related material
contained in this publication has been approved by the Korea Accounting Standards Board in
Korea with the permission of the IFRS Foundation.
The Korean translation is the copyright of the
IFRS Foundation.
Copies of the Korean translation may be obtained from the IFRS Foundation or
the KASB, KCCI Building 3rd Flr., 39 Sejong-daero, Jung-gu, Seoul, 04513, Korea.
Tel: +82 (0)2 6050 0150
Fax: +82 (0)2 6050 0170
Email: webmaster@kasb.or.kr
Web: www.kasb.or.kr
The IFRS Foundation has waived the right to assert its copyright in certain materials in the
Korean language, such materials consist of all numbered, bare International Accounting Standards
(IASs) and International Financial Reporting Standards (IFRSs) in the form that they are issued or
adopted by the IASB, or Interpretations issued by the IFRS Interpretations Committee (IFRS IC) or
Standing Interpretations Committee (SIC) (hereinafter referred to as 'integral part of the standards'),
in the territory of the Republic of Korea with sovereign consent and in connection with any use
of the integral part of the standards outside of the Republic of Korea by any foreign subsidiary,
joint venture, associate or branch of a corporation, which resides in the Republic of Korea.
Reproduction of the integral part of the standards in the Korean language is permitted for any use
within the Republic of Korea and by any foreign subsidiary, joint venture, associate or branch of a
corporation, which resides in the Republic of Korea.
The IFRS Foundation reserves all rights outside of the Republic of Korea and in any use other
than use of the integral part of the standards in the Korean language by any foreign subsidiary,
joint venture, associate or branch of a corporation, which resides in the Republic of Korea.
