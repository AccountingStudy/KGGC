- 280 -
제․개정 경과
한국회계기준원 회계기준위원회는 국제회계기준위원회가 제정한 국제회계기
준을 채택하여 기업회계기준의 일부로 구성하기로 한 정책에 따라 이 개념체
계를 다음과 같이 개정하였다.
이 기준서는 타 기준서의 제․개정에 따라 다음과 같이 개정되었다.
제·개정일자
한국채택국제회계기준
관련되는 국제회계기준
2011. 7. 22.
제정
재무보고를 위한 개념체계
The
Conceptual
Framework
for
Financial Reporting
2018. 12. 21.
전면개정
재무보고를 위한 개념체계
Conceptual
Framework
for
Financial Reporting
제․개정 일자
타 기준서
관련되는 국제회계기준
2019.4.19. 개정
‘중요성의 정의’ (기업회
계기준서 제1001호 및 
제1008호의 개정)
Definition
of
Material
(Amendments
to
IAS
1
and
IAS 8)
