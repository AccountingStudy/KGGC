- 123 -
‘Conceptual Framework for Financial Reporting’의 결론도출근거 관련 참고사항
이 결론도출근거는 국제회계기준의 제정주체(IASB, IASC, IFRIC 등)가 IFRS
를 제정한 과정과 외부의견 등에 대한 논의내용 등을 기술한 것이다.
이 결론도출근거는 국제회계기준의 이용자를 위해 IASB가 작성한 문서이지
만 한국채택국제회계기준을 이해하는데 매우 유용하므로 원문을 번역하여 
제공한다.
이 결론도출근거에 언급되는 국제회계기준의 개별 기준서 및 해석서에 각각 
대응되는 K-IFRS의 개별 기준서 및 해석서를 이용자들이 보다 쉽게 파악할 
수 있도록 아래의 대응표를 제시한다.
국제회계기준
한국채택국제회계기준
Framework for the Presentation and
Presentation of Financial Statements
(1989, 2001)
재무제표의 작성과 표시를 위한 
개념체계(2007)
Conceptual Framework for Financial
Reporting (2010)
재무보고를 위한 개념체계(2011)
Conceptual Framework for Financial
Reporting (2018)
재무보고를 위한 개념체계(2018)
