- 124 -
‘재무보고를 위한 개념체계(Conceptual Framework for Financial
Reporting)’의 결론도출근거
이 결론도출근거는 Conceptual Framework for Financial Reporting 에 첨부되지
만, 그 일부를 구성하지는 않는다. IASB 가 개념체계를 개발하는 과정에서 
고려한 사항을 이 결론도출근거에서 요약한다. IASB 위원들은 개인에 따라 
일부 사항을 다른 사항들보다 더 비중을 두고 다루었다.
